# Project Title: Admin and Employee Portal

## Overview
This project is designed to demonstrate advanced state management using Redux in a React application. It features a system where users can either be admins or employees, with different privileges and accessible pages for each type. The project includes functionalities such as user management, job postings, and job listings, with a focus on secure and efficient data handling.

## Technical Features

- **React** for the frontend user interface.
- **Redux** for global state management, ensuring a unidirectional data flow and centralized state.
- **Express.js** and **MongoDB** for the backend, handling API requests and database operations.
- **Material UI** for designing responsive and visually appealing components.
- **Axios** for promise-based HTTP requests to connect the frontend with the backend API.
- **React Router** for declarative routing within the application, supporting protected routes based on user roles.
- **Environment Variables** for managing different configurations between development and production environments.

## Key Functionalities

- **User Registration and Login**: Support for different user types (admin and employee) with secure authentication.
- **Admin Portal**:
  - Ability to create job postings.
  - Viewing and managing all registered users except for their passwords.
- **Employee Portal**:
  - Viewing available job listings.
- **Protected Routes**: Restricting page access based on user authentication and roles.
- **Dynamic Navigation**: Conditional navigation based on user role (admin or employee).
- **API Interactions**: Creating and fetching data from a MongoDB database using Express.js.

## Getting Started

### Prerequisites

- Node.js and npm installed.
- MongoDB running locally or remotely.

### Additional Functionality
- Loading Indicator
- Job Pagination
