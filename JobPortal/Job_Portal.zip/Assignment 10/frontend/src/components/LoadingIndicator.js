import React from 'react';
import { CircularProgress } from '@mui/material';


function LoadingIndicator() {
  return (
    <div className="loading-indicator">
      <CircularProgress />
    </div>
  );
}

export default LoadingIndicator;
