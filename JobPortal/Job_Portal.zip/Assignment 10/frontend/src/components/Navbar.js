import React from 'react';
import { useSelector } from 'react-redux';
import { selectUser } from '../features/UserSlice';
import { Link } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { logout } from '../features/UserSlice';
import { Button } from '@mui/material';

function Navbar() {
  const user = useSelector(selectUser);
  const dispatch = useDispatch();

  const handleLogout = () => {
    dispatch(logout());
    // Redirect to login page or home page as needed
    window.location.href = '/login';
  };
  return (
    <div className="navbar">
      <Link to="/">Home</Link>
      {user && user.type === 'admin' && <Link to="/add-jobs">Add Jobs</Link>}
      {user && <Link to="/jobs">Jobs</Link>}
      {user && user.type === 'admin' && <Link to="/admin">Admin</Link>}
      {user && (
      <Button onClick={handleLogout}>Logout</Button>)}
    </div>
  );
}

export default Navbar;
