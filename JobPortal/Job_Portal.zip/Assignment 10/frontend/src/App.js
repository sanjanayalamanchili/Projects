import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { selectUser } from './features/UserSlice';
import AdminPage from './pages/AdminPage.js';
import EmployeePage from './pages/EmployeePage.js';
import LoginPage from './pages/LoginPage.js';
import JobsPage from './pages/JobsPage.js';
import AddJobsPage from './pages/AddJobsPage.js';
import Navbar from './components/Navbar.js';

function App() {
  const user = useSelector(selectUser);

  const ProtectedRoute = ({ children }) => (
    user ? children : <Navigate to="/login" replace />
  );

  const AdminRoute = ({ children }) => (
    user?.type === 'admin' ? children : <Navigate to="/" replace />
  );

  const EmployeeRoute = ({ children }) => (
    user?.type === 'employee' ? children : <Navigate to="/" replace />
  );

  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/admin" element={<ProtectedRoute>{<AdminRoute>{user?.type === 'admin' ? <AdminPage /> : <Navigate to="/" />}</AdminRoute>}</ProtectedRoute>} />
        <Route path="/add-jobs" element={<ProtectedRoute>{<AdminRoute>{user?.type === 'admin' ? <AddJobsPage /> : <Navigate to="/" />}</AdminRoute>}</ProtectedRoute>} />
        <Route path="/jobs" element={<ProtectedRoute>{<EmployeeRoute>{user?.type === 'employee' ? <JobsPage /> : <Navigate to="/" />}</EmployeeRoute>}</ProtectedRoute>} />
        <Route path="/" element={<ProtectedRoute>{user?(user?.type === 'admin' ? <AdminPage /> : <EmployeePage />) : <Navigate to="/login" />}</ProtectedRoute>} />
        {/* Redirects any unknown routes */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;
