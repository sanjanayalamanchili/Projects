import { createSlice } from '@reduxjs/toolkit';

export const jobsSlice = createSlice({
  name: 'jobs',
  initialState: {
    jobsList: [],
  },
  reducers: {
    setJobs: (state, action) => {
      state.jobsList = action.payload;
    },
    addJob: (state, action) => {
      state.jobsList.push(action.payload);
    },
  },
});

export const { setJobs, addJob } = jobsSlice.actions;

export const selectJobs = (state) => state.jobs.jobsList;

export default jobsSlice.reducer;
