import React, { useEffect, useState } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { logout, selectUser } from '../features/UserSlice';
import { Button } from '@mui/material';
import LoadingIndicator from '../components/LoadingIndicator';

import axios from 'axios';

function AdminPage() {
  const [users, setUsers] = useState([]);
  const dispatch = useDispatch();
  const user = useSelector(selectUser);
  // if (!user) {
  //   return <LoadingIndicator />;
  // }
  const [loading, setLoading] = useState(true);
  const handleLogout = () => {
    dispatch(logout());
    // Redirect to login page or home page as needed
    window.location.href = '/login';
  };
  
  useEffect(() => {
    const fetchUsers = async () => {
      setLoading(true);
      const response = await axios.get('http://localhost:5000/users'); // Adjust the API endpoint as needed
      setUsers(response.data);
      setLoading(false);
    };
    fetchUsers();
  }, []);

  

  return (
    <div>  
      {loading && <LoadingIndicator />}
    <TableContainer component={Paper}>
      <Table aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>Email</TableCell>
            <TableCell align="right">Name</TableCell>
            <TableCell align="right">Type</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {users.map((user) => (
            <TableRow key={user._id}>
              <TableCell component="th" scope="row">
                {user.email}
              </TableCell>
              <TableCell align="right">{user.fullName}</TableCell>
              <TableCell align="right">{user.type}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    </div>
  );
}

export default AdminPage;
