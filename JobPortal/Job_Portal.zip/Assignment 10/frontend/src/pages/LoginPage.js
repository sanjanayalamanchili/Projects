import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { setUser } from '../features/UserSlice';
import { Button, TextField, Container, Typography, RadioGroup, FormControlLabel, Radio } from '@mui/material';
import LoadingIndicator from '../components/LoadingIndicator';
import axios from 'axios';
import Navbar from '../components/Navbar';

function LoginPage() {
  const [credentials, setCredentials] = useState({ email: '', password: '', fullName: '', type: 'employee' });
  const [loading, setLoading] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const dispatch = useDispatch();
  const history = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCredentials(prevState => ({
      ...prevState,
      [name]: value,
    }));
  };

  const toggleRegister = () => setIsRegistering(!isRegistering);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const url = isRegistering ? 'http://localhost:5000/user/create' : 'http://localhost:5000/user/login';
    try {
      const response = await axios.post(url, credentials);
      dispatch(setUser(response.data));
      history('/'); // Redirect based on user type could be implemented here
    } catch (error) {
      console.error('Operation failed:', error);
      // Handle failure (e.g., show an error message)
    }
    setLoading(false);
  };

  if (loading) {
    return <LoadingIndicator />;
  }

  return (
    <div>
      {/* <Navbar /> */}
    
    <Container component="main" maxWidth="xs">
      <Typography component="h1" variant="h5">{isRegistering ? 'Register' : 'Login'}</Typography>
      {isRegistering && (
        <>
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            label="Full Name"
            name="fullName"
            onChange={handleChange}
            value={credentials.fullName}
          />
          <RadioGroup aria-label="type" name="type" value={credentials.type} onChange={handleChange} row>
            <FormControlLabel value="employee" control={<Radio />} label="Employee" />
            <FormControlLabel value="admin" control={<Radio />} label="Admin" />
          </RadioGroup>
        </>
      )}
      <TextField
        variant="outlined"
        margin="normal"
        required
        fullWidth
        label="Email"
        name="email"
        onChange={handleChange}
        value={credentials.email}
      />
      <TextField
        variant="outlined"
        margin="normal"
        required
        fullWidth
        name="password"
        label="Password"
        type="password"
        onChange={handleChange}
        value={credentials.password}
      />
      <Button
        type="submit"
        fullWidth
        variant="contained"
        color="primary"
        onClick={handleSubmit}
      >
        {isRegistering ? 'Register' : 'Sign In'}
      </Button>
      <Button
        fullWidth
        variant="text"
        onClick={toggleRegister}
      >
        {isRegistering ? 'Switch to Login' : 'Switch to Register'}
      </Button>
    </Container>
    </div>
  );
}

export default LoginPage;
