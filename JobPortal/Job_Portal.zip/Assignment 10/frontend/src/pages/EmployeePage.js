import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, Container, Typography } from '@mui/material';
import "./styles/emp.css"

function EmployeePage() {
    const navigate = useNavigate();

  return (
    <Container component="main">
      <Typography component="h1" variant="h5">Welcome, Employee</Typography>
      <Button
        variant="contained"
        color="primary"
        onClick={() => navigate('/jobs')}
      >
        View Jobs
      </Button>
    </Container>
  );
}

export default EmployeePage;
