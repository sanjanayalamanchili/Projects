import React, { useEffect, useState } from 'react';
import { Card, CardContent, Typography, Grid, Button } from '@mui/material';
import axios from 'axios';
import LoadingIndicator from '../components/LoadingIndicator';            
function JobsPage() {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);


  useEffect(() => {

    const fetchJobs = async () => {
      setLoading(true);
      const response = await axios.get('http://localhost:5000/get/jobs'); 
      console.log(response)// Adjust the API endpoint as needed
      setJobs(response.data.jobs);
      setLoading(false);
    };
    fetchJobs();
  }, []);

  if (loading) {
    return <LoadingIndicator />;
  }
  

  return (
    <div>
      {/* <Navbar /> */}
    <Grid container spacing={3}>
      {Array.isArray(jobs) && jobs.map((job) => (
        <Grid item key={job._id} xs={12} sm={6} md={4}>
          <Card>
            <CardContent>
              <Typography gutterBottom variant="h5" component="h2">
                {job.jobTitle}
              </Typography>
              <Typography variant="body2" color="textSecondary" component="p">
                {job.description}
              </Typography>
              <Typography variant="body2" color="textSecondary" component="p">
                Salary: {job.salary} $
              </Typography>
              <Button variant="contained" color="primary">
                Apply
              </Button>
              {/* Additional job details can be displayed here */}
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
    </div>
  );
}

export default JobsPage;
