import React, { useState } from 'react';
import { Button, TextField, Container, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

function AddJobsPage() {
  const [jobDetails, setJobDetails] = useState({
    companyName: '',
    jobTitle: '',
    description: '',
    salary: 0,
  });
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setJobDetails(prevState => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Post request to create job
    await axios.post('http://localhost:5000/create/job', jobDetails);
    // Reset form or show success message
    navigate('/jobs');
  };

  return (
    <Container component="main" maxWidth="xs">
      <Typography component="h1" variant="h5">
        Add Job
      </Typography>
      <form onSubmit={handleSubmit}>
        <TextField
          variant="outlined"
          margin="normal"
          required
          fullWidth
          label="Company Name"
          name="companyName"
          autoFocus
          onChange={handleChange}
          value={jobDetails.companyName}
        />
        <TextField
          variant="outlined"
          margin="normal"
          required
          fullWidth
          name="jobTitle"
          label="Job Title"
          onChange={handleChange}
          value={jobDetails.jobTitle}
        />
        <TextField
          variant="outlined"
          margin="normal"
          required
          fullWidth
          name="description"
          label="Description"
          multiline
          rows={4}
          onChange={handleChange}
          value={jobDetails.description}
        />
        <TextField
          variant="outlined"
          margin="normal"
          required
          fullWidth
          name="salary"
          label="Salary"
          type="number"
          onChange={handleChange}
          value={jobDetails.salary}
        />
        <Button
          type="submit"
          fullWidth
          variant="contained"
          color="primary"
        >
          Add Job
        </Button>
      </form>
    </Container>
  );
}

export default AddJobsPage;
