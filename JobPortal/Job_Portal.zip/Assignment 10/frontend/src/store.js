import { configureStore } from '@reduxjs/toolkit';
import userReducer from './features/UserSlice';
import jobReducer from './features/JobsSlice';

export default configureStore({
  reducer: {
    user: userReducer,
    job: jobReducer,
  },
});
