const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();

const port = process.env.PORT || 5000;
const url = "mongodb://127.0.0.1:27017/a10";

// Middleware
app.use(cors());
app.use(bodyParser.json());

// MongoDB connection
mongoose.connect(url, { useNewUrlParser: true, useUnifiedTopology: true });

// Routes
app.get('/', (req, res) => res.send('Hello World!'));
const user_router = require('./apis/users');
app.use(user_router);
const  job_router  = require('./apis/jobs');
app.use(job_router);

app.listen(port, () => console.log(`Server running on port ${port}`));
