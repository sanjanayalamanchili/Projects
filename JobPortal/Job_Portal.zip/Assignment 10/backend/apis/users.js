const User = require('../models/user');
const bcrypt = require('bcryptjs');
const express = require('express');
const router = express.Router();


router.post('/user/create', async (req, res) => {
  const { fullName, email, password, type } = req.body;
  if (!['employee', 'admin'].includes(type)) {
    return res.status(400).send({ error: 'Type must be either "employee" or "admin".' });
  }
  try {
    // Hash password before saving to database
    const hashedPassword = await bcrypt.hash(password, 8);
    const user = new User({ fullName, email, password: hashedPassword, type });
    await user.save();
    res.status(201).send({ id: user._id, fullName, email, type });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).send({ error: 'Email already exists.' });
    }
    res.status(500).send({ error: 'All fields required' });
  }
});

app.get('/users', async (req, res) => {
  try {
    const users = await User.find().select('-password');
    res.json(users);
  } catch (error) {
    res.status(500).send('Error fetching users.');
  }
});

router.post('/user/login', async (req, res) => {
    const { email, password } = req.body;
    try {
      const user = await User.findOne({ email });
      if (!user) {
        return res.status(404).send({ error: 'User not found' });
      }
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.status(400).send({ error: 'Invalid credentials' });
      }
      res.send({ id: user._id, fullName: user.fullName, email: user.email, type: user.type });
    } catch (error) {
      res.status(500).send({ error: 'Internal server error' });
    }
  });






module.exports = router;
