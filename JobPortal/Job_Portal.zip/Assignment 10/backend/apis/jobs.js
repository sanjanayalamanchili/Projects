const Job = require('../models/job');

const express = require('express');
const router = express.Router();

router.get('/get/jobs', async (req, res) => {
  const { page = 1, limit = 10 } = req.query;
  try {
    const jobs = await Job.find({})
      .limit(limit * 1)
      .skip((page - 1) * limit);
    const count = await Job.countDocuments();
    res.send({
      jobs,
      totalPages: Math.ceil(count / limit),
      currentPage: page,
    });
  } catch (error) {
    res.status(500).send({ error: 'Internal server error' });
  }
});

// POST /create/job endpoint
router.post('/create/job', async (req, res) => {
  const { companyName, jobTitle, description, salary } = req.body;
  // Optional: Add authentication to verify user type is 'admin'
  
  try {
    const job = new Job({ companyName, jobTitle, description, salary });
    await job.save();
    res.status(201).send({ message: 'Job created successfully', job });
  } catch (error) {
    res.status(500).send({ error: 'Internal server error' });
  }
});


module.exports = router;