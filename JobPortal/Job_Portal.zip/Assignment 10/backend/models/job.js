// Job.js
const mongoose = require('mongoose');

const jobSchema = new mongoose.Schema({
  companyName: String,
  jobTitle: String,
  description: String,
  salary: Number,
  // Add more fields as necessary
});

module.exports = mongoose.model('Job', jobSchema);
