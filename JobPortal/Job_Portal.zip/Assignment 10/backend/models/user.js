// User.js
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  fullName: String,
  email: String,
  password: String, // Consider hashing in a real app
  type: { type: String, enum: ['employee', 'admin'] },
});

module.exports = mongoose.model('User', userSchema);
