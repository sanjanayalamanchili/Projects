# Coffee Co Website

## Features Implemented

1. CSS Grid Layout: Used in the "services" and "team" sections to display items in a grid format.
2. Flexbox Layout: Used in the navigation bar and the "review" section to align and distribute space among items.
3. SASS/SCSS Features:
   - Variables: Used for colors, font families, and other reusable values.
   - Nesting: Used to nest CSS selectors for better organization and readability.
   - Mixins: Created mixins for common styles like buttons and icons.
   - Functions: Used functions to perform calculations for responsive font sizes and spacing.
   - Interpolation: Used to dynamically construct class names in the "services" section.
   - Placeholder Selectors: Utilized for creating reusable styles for headings and paragraphs.

## Implementation Details

- Home Section: Implemented using Flexbox to center the content and align the image and text side by side.
- Services Section: Utilized CSS Grid to display the services in a grid format. Each service is represented by an image and a description.
- Products Section: Redirects to a separate "products.html" page, showcasing the implementation of multiple pages.
- Team Section: Used CSS Grid to display the team members in a grid layout, with each member's photo, name, role, and description.
- Reviews Section: Implemented a swiper slider using the Swiper.js library to display customer reviews in a carousel format.
- Booking Section: Includes a form for booking a table, demonstrating form implementation and input styling.
- **Footer:** Organized into different sections using Flexbox, providing links to various pages and social media icons.

## Additional Notes

- The website is responsive, with media queries used to adjust the layout and design for different screen sizes.
- ScrollReveal.js is used to add scroll animations to various sections for a more dynamic user experience.

---
